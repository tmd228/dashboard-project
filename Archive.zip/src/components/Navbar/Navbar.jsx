import styles from "./Navbar.module.css"
import { Link } from "react-router-dom"


export default function Navbar() {
    return (
        <h1>navbar</h1>
    )
}