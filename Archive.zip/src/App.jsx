import './App.css'
import ChartCard from './components/ChartCard/ChartCard'
import Navbar from './components/Navbar/Navbar'
import Sidebar from './components/Sidebar/Sidebar'
import Dashboard from './pages/Dashboard/Dashboard'
import NotFound from './pages/NotFound/NotFound'
import Settings from './pages/Settings/Settings'
import { Route, Routes } from 'react-router-dom'

function App() {

  return (<div>
    <h1>hello</h1>
  </div>
  )
}

export default App
